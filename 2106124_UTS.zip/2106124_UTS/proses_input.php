<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tanggal = $_POST['tanggal'];
    $no_plat = $_POST['no_plat'];
    $lokasi_tilang = $_POST['lokasi_tilang'];
    $nama_pengguna = $_POST['nama_pengguna'];
    $no_hubungi = $_POST['no_hubungi'];
    $alamat = $_POST['alamat'];


    $platRegex = '/^[A-Za-z]{1,2}\d{4}[A-Za-z]{2}$/';
    if (!preg_match($platRegex, $no_plat)) {
        echo "Nomor Plat tidak valid (contoh: Z5842DA)";
    } else {
        if ($no_hubungi < 0) {
            echo "<div id='error'>Masukkan angka positif</div>";
        } else {
            $query = "INSERT INTO tilang(tanggal, no_plat, lokasi_tilang, nama_pengguna, no_hubungi, alamat) VALUES('$tanggal', '$no_plat', '$lokasi_tilang', '$nama_pengguna', '$no_hubungi','$alamat')";
            
            if (mysqli_query($koneksi, $query)) {
                echo "Data berhasil disimpan";
                header("Location: ./index.php"); 
                exit;
            } else {
                echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
            }
        }
    }
}


echo "Tidak ada data yang di-submit.";

mysqli_close($koneksi);
?>

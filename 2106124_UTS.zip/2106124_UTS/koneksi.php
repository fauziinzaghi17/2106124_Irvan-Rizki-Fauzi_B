<?php
$koneksi = mysqli_connect("localhost", "root", "","2106124_irvan");
if (!$koneksi) {
echo "<script>alert('koneksi database gagal');</script>";
}
?>
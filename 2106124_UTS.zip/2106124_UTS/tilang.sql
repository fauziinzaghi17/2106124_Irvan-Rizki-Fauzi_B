-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 24 Nov 2023 pada 03.49
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2106124_irvan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tilang`
--

CREATE TABLE `tilang` (
  `id_tilang` int(10) NOT NULL,
  `tanggal` date NOT NULL,
  `no_plat` varchar(10) NOT NULL,
  `lokasi_tilang` varchar(30) NOT NULL,
  `nama_pengguna` varchar(30) NOT NULL,
  `no_hubungi` varchar(16) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tilang`
--

INSERT INTO `tilang` (`id_tilang`, `tanggal`, `no_plat`, `lokasi_tilang`, `nama_pengguna`, `no_hubungi`, `alamat`) VALUES
(9, '2023-11-03', 'Z5842DA', 'Ngamplang, Cilawu', 'Irvan Fauzi', '089744508095', 'Bamdung Kota'),
(10, '2023-11-03', 'Z6689AC', 'Ngamplang, Cilawu', 'Robert Kicman', '082188806542', 'Tasikmalaya'),
(11, '2023-11-03', 'Z9786KL', 'Ngamplang, Cilawu', 'Amin Maskduk', '089311867791', 'Sukaregang');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tilang`
--
ALTER TABLE `tilang`
  ADD PRIMARY KEY (`id_tilang`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tilang`
--
ALTER TABLE `tilang`
  MODIFY `id_tilang` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

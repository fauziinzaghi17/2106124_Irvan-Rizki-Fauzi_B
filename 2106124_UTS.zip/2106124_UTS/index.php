<!DOCTYPE html>


<head>
    <title>Form Tilang</title>
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <div class="container">
        <h2>Form Tilang</h2>
        
        <form action="proses_input.php" method="POST">
            
            <label for="tanggal">Tanggal Tilang:</label>
            <input type="date" name="tanggal" required>

            <label for="no_plat">Nomor Plat Kendaraan:</label>
            <input type="text" name="no_plat" required>

            <label for="lokasi_tilang">Lokasi Tilang:</label>
            <input type="text" name="lokasi_tilang" required>

            <label for="nama_pengguna">Nama Pengguna:</label>
            <input type="text" name="nama_pengguna" required>

            <label for="no_hubungi">Nomor Yang Dapat Dihubungi:</label>
            <input type="number" name="no_hubungi" required>

            <label for="alamat">Alamat:</label>
            <textarea name="alamat" required></textarea>

            <button type="submit">Submit</button>
        
        </form>
    </div>
</body>

</html>
